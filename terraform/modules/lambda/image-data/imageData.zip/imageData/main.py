from helper.insert import insert_new_image                  # type: ignore
from helper.migration import create_schema                  # type: ignore
from helper.search import search_label, get_http_params     # type: ignore

# Retrieves event from EventBridge and then CloudFormation.

def handler(event, context):
    if "ResourceProperties" in event:
        body = event["ResourceProperties"]
        for k in body: event[k] = body[k]

    if "body" in event:
        body = get_http_params(event["body"])
        for k in body: event[k] = body[k]

    source = event["source"]

    if source == "Cloudformation":                          # CloudFormation -> Schema.
        return create_schema()
    elif source == "EventBridge":                           # EventBridge   -> Labels.
        image_id = event["detail"]["image_id"]
        labels = event["detail"]["labels"]
        response = insert_new_image(image_id, labels)
        return response
    elif source == "API":                                   # API Gateway -> Search.
        if "language" in event:
            response = search_label(event["label"], event["country"], event["language"])
        else:
            response = search_label(event["label"])

        return response